import React, { useMemo, useState } from 'react';
import { Activity, BarChart3, Bot, BrainCircuit, CandlestickChart, ChevronDown, CircleHelp, Clock3, Gauge, LayoutDashboard, Menu, Play, ScanSearch, Settings, ShieldCheck, SlidersHorizontal, Wallet, X } from 'lucide-react';

const nav = [
  ['Overview', LayoutDashboard], ['AI Scanner', BrainCircuit], ['Bulk Trader', SlidersHorizontal],
  ['Bot Builder', Bot], ['SpeedBot', Gauge], ['Digit Scanner', ScanSearch],
  ['Manual Trader', CandlestickChart], ['Auto Trader', Play], ['Charts', BarChart3]
];
const markets = ['Volatility 100 Index','Volatility 75 Index','Volatility 50 Index','Volatility 25 Index','Volatility 10 Index','Boom 500 Index','Crash 500 Index'];
function App(){
  const [active,setActive]=useState('Overview');
  const [market,setMarket]=useState(markets[0]);
  const [stake,setStake]=useState('1');
  const [duration,setDuration]=useState('5');
  const [contract,setContract]=useState('DIGITOVER');
  const [digit,setDigit]=useState('5');
  const [connected,setConnected]=useState(false);
  const [notice,setNotice]=useState('Connect a Deriv account to enable live account data and trading.');
  const [mobile,setMobile]=useState(false);
  const title = active === 'Overview' ? 'Trading overview' : active;
  const stats = useMemo(()=>[{label:'Account balance',value:connected?'Connected':'—',icon:Wallet},{label:'Today’s profit/loss',value:'—',icon:Activity},{label:'Open positions',value:'0',icon:BarChart3},{label:'Risk status',value:'Protected',icon:ShieldCheck}], [connected]);
  function connect(){setNotice('Demo connection mode selected. Add your Deriv App ID and complete OAuth setup before enabling account access.');setConnected(true);}
  function runScan(){setNotice(`Scanner prepared for ${market}. Connect Deriv and configure a data feed to run live analysis.`);}
  function trade(){setNotice('Trade not sent: connect and authorize a Deriv account first. No order has been placed.');}
  return <div className="shell">
    <aside className={`sidebar ${mobile?'show':''}`}>
      <div className="brand"><div className="brandmark">T</div><div><b>TickLab</b><small>TRADING WORKSPACE</small></div><button className="close" onClick={()=>setMobile(false)}><X size={18}/></button></div>
      <div className="navlabel">WORKSPACE</div>
      {nav.map(([label,Icon])=><button key={label} className={`navitem ${active===label?'selected':''}`} onClick={()=>{setActive(label);setMobile(false)}}><Icon size={17}/><span>{label}</span>{label==='AI Scanner'&&<i>AI</i>}</button>)}
      <div className="sidebottom"><button className="navitem" onClick={()=>setActive('Settings')}><Settings size={17}/>Settings</button><div className="help"><CircleHelp size={17}/><span>Need help?</span><small>Read setup guide</small></div></div>
    </aside>
    {mobile&&<div className="scrim" onClick={()=>setMobile(false)}/>}
    <main className="main">
      <header className="topbar"><button className="hamb" onClick={()=>setMobile(true)}><Menu/></button><div className="crumb">Workspace <span>/</span> {active}</div><div className="topright"><span className="marketstatus"><b/> Markets</span><button className="connect" onClick={connect}><Wallet size={16}/> Connect Deriv</button><div className="avatar">TL</div></div></header>
      <div className="content">
        <div className="heading"><div><div className="eyebrow">TICKLAB WORKSPACE</div><h1>{title}</h1><p>Analyze markets, configure strategies and manage risk.</p></div><div className="datepill"><Clock3 size={15}/> Live workspace</div></div>
        <div className="notice"><ShieldCheck size={17}/><span>{notice}</span></div>
        {active==='Overview'?<>
          <div className="stats">{stats.map(({label,value,icon:Icon})=><div className="stat" key={label}><div className="stathead"><span>{label}</span><Icon size={17}/></div><strong>{value}</strong><small>{label==='Risk status'?'Risk controls enabled':'Awaiting Deriv authorization'}</small></div>)}</div>
          <div className="gridmain">
            <section className="panel chartpanel"><div className="panelhead"><div><h2>Market watch</h2><p>Choose a market to inspect</p></div><select value={market} onChange={e=>setMarket(e.target.value)}>{markets.map(m=><option key={m}>{m}</option>)}</select></div><div className="chartplaceholder"><div className="charttop"><span>{market}</span><span className="muted">DEMO DATA PLACEHOLDER</span></div><svg viewBox="0 0 720 220" preserveAspectRatio="none"><defs><linearGradient id="area" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#25d6a2" stopOpacity=".22"/><stop offset="1" stopColor="#25d6a2" stopOpacity="0"/></linearGradient></defs>{[40,90,140,190].map(y=><line key={y} x1="0" x2="720" y1={y} y2={y} stroke="#202b3d" strokeDasharray="4 5"/>)}<path d="M0 165 L35 145 L70 154 L105 105 L140 122 L175 88 L210 115 L245 75 L280 98 L315 60 L350 83 L385 45 L420 72 L455 52 L490 93 L525 70 L560 100 L595 61 L630 76 L665 35 L720 48 L720 220 L0 220Z" fill="url(#area)"/><path d="M0 165 L35 145 L70 154 L105 105 L140 122 L175 88 L210 115 L245 75 L280 98 L315 60 L350 83 L385 45 L420 72 L455 52 L490 93 L525 70 L560 100 L595 61 L630 76 L665 35 L720 48" fill="none" stroke="#25d6a2" strokeWidth="2.5"/></svg><div className="chartfoot"><span>Chart preview only</span><span>Connect a market data feed for live prices</span></div></div></section>
            <section className="panel scanner"><div className="panelhead"><div><h2><BrainCircuit size={19}/> AI Market Scanner</h2><p>Scan selected synthetic markets</p></div><span className="tag">BETA</span></div><label>Market</label><select value={market} onChange={e=>setMarket(e.target.value)}>{markets.map(m=><option key={m}>{m}</option>)}</select><label>Scan mode</label><div className="twobtn"><button className="active">Deep scan</button><button onClick={()=>setNotice('Quick scan selected. Connect a live data feed to analyze markets.')}>Quick scan</button></div><button className="primary full" onClick={runScan}><ScanSearch size={17}/> Scan market</button><div className="scannerfoot"><ShieldCheck size={15}/> Signals are informational, not guarantees.</div></section>
          </div>
          <section className="panel quick"><div className="panelhead"><div><h2>Quick tools</h2><p>Open a workspace tool</p></div></div><div className="quickgrid">{nav.slice(1).map(([label,Icon])=><button key={label} onClick={()=>setActive(label)}><Icon size={19}/><span>{label}</span><ChevronDown size={14}/></button>)}</div></section>
        </>:<div className="toolgrid"><section className="panel"><div className="panelhead"><div><h2>{active} configuration</h2><p>Configure your strategy before running it.</p></div><span className="tag">SETUP</span></div><label>Market</label><select value={market} onChange={e=>setMarket(e.target.value)}>{markets.map(m=><option key={m}>{m}</option>)}</select><label>Contract type</label><select value={contract} onChange={e=>setContract(e.target.value)}><option>DIGITOVER</option><option>DIGITUNDER</option><option>DIGITEVEN</option><option>DIGITODD</option><option>DIGITMATCH</option><option>DIGITDIFF</option></select><div className="formrow"><div><label>Stake (USD)</label><input value={stake} onChange={e=>setStake(e.target.value)} type="number" min="0.35" step="0.01"/></div><div><label>Duration (ticks)</label><input value={duration} onChange={e=>setDuration(e.target.value)} type="number" min="1"/></div></div><label>Prediction digit</label><div className="digits">{Array.from({length:10},(_,n)=><button className={digit===String(n)?'chosen':''} onClick={()=>setDigit(String(n))} key={n}>{n}</button>)}</div><button className="primary full" onClick={trade}><Play size={16}/> {active==='Manual Trader'?'Review trade':'Run '+active}</button><p className="fineprint">Execution is disabled until a Deriv account is securely connected and the required API permissions are configured.</p></section><section className="panel sideinfo"><h2><ShieldCheck size={19}/> Risk controls</h2><p>Use strict limits before enabling automated execution.</p><div className="riskrow"><span>Maximum stake</span><b>Set in settings</b></div><div className="riskrow"><span>Daily loss limit</span><b>Set in settings</b></div><div className="riskrow"><span>Martingale</span><b className="good">Disabled by default</b></div><div className="riskrow"><span>Live execution</span><b className="warn">Not connected</b></div></section></div>}
        <footer>TickLab © 2026 <span>Independent third-party interface · Not affiliated with Deriv</span></footer>
      </div>
    </main>
  </div>
}
export default App;