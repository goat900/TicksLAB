# TickLab — Deriv Trading Workspace

TickLab is a responsive React/Vite frontend starter for an independent third-party Deriv trading interface. It includes a dashboard, market scanner UI, strategy configuration screens, and risk-control placeholders.

## Included modules
- Overview dashboard and market watch preview
- AI Scanner (UI scaffold)
- Bulk Trader
- Bot Builder
- SpeedBot
- Digit Scanner
- Manual Trader
- Auto Trader
- Charts
- Settings navigation entry
- Responsive desktop and mobile layout

## Requirements
- Node.js 20 or newer
- npm
- A Deriv account and a registered Deriv application for API/OAuth integration

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Build
```bash
npm run build
```
The production website is generated in the `dist` folder.

## Deploy to Cloudflare Pages using GitHub
1. Create a GitHub repository named `ticklab`.
2. Upload the contents of this project folder to the repository root (do not upload the ZIP itself).
3. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git**.
4. Select the `ticklab` repository.
5. Set **Framework preset** to `Vite`.
6. Set **Build command** to `npm run build`.
7. Set **Build output directory** to `dist`.
8. Save and deploy. Cloudflare will provide a `*.pages.dev` address.

## Deriv API connection — important
This package deliberately does **not** contain API credentials, OAuth client secrets, or a live trading implementation. The Connect Deriv button is a safe setup placeholder; it does not authenticate or place trades.

To enable real account access:
1. Register an application in the Deriv API dashboard.
2. Configure the exact deployed HTTPS redirect URL in the Deriv application settings.
3. Implement Deriv's current OAuth authorization-code flow and validate the callback server-side.
4. Keep client secrets and tokens out of browser source code and GitHub. Use Cloudflare Workers secrets for server-side secrets.
5. For live trading, request only the required account permissions and show a clear confirmation before sending orders.
6. Test the complete flow on a demo account before considering real-account use.

Use the official documentation: https://developers.deriv.com/

## Current implementation status
- Frontend navigation and responsive UI: implemented
- Market chart: illustrative placeholder, not live market data
- Scanner: UI placeholder, not an AI prediction engine
- Deriv OAuth/API: not yet connected
- Trade execution: intentionally disabled until secure authorization and risk controls are implemented
- Risk controls: display/configuration placeholders; do not treat them as an audited risk engine

## Risk notice
Binary options and synthetic-index trading involve substantial risk. No win rate or profit is guaranteed. Automated strategies can lose money quickly. Use demo mode first, set strict stake and daily-loss limits, and never use funds you cannot afford to lose.

TickLab is an independent project and is not affiliated with, endorsed by, or operated by Deriv.
