# TickLab

Binary analysis and practice tool. Simulated market, fake $1,000 balance.
No Deriv connection, no tokens, no real trades.

## Files
- index.html : the whole app (one file, no build step)
- README.md  : this file

## Tabs
Home, Manual, Auto, Risk, Builder, Free Bots, Tutorials, plus the floating AI scanner.

## Host it
1. Create a free account on Netlify, GitHub Pages, or Cloudflare Pages.
2. Upload index.html (Netlify: drag and drop the ticklab folder).
3. Open the https link it gives you.

## Next step (not built yet)
Connect to Deriv's demo account via developers.deriv.com:
register an app, create a demo token with the trade scope only,
and replace the simulated ticks/trades with the API. Keep tokens private.

## Notes
- All outcomes are random with a 95% payout, so expected result is about -5% of stake.
- Download CSV works on the hosted copy.

## Deriv login (Account tab)
Read-only account dashboard. Uses Deriv's OAuth login (oauth.deriv.com) with your App ID,
then authorizes over WebSocket and shows account, balance and token scopes.
Register the hosted https URL as the app's redirect URL on developers.deriv.com.
Tokens are kept in memory only. It does not place real trades.
